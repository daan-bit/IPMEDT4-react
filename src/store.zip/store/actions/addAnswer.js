function addAnswer (payload) {
    return {
        type: 'ADD_ANSWER',
        payload
    }
} 

export default addAnswer